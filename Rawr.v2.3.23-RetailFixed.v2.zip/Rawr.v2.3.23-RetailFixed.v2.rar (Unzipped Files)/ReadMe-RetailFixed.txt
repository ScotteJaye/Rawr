Notes on this Edition:
- Edited character and pets talent sheets with optimizations.
- Now it shows all the icons correctly. Thanks to suicidalkatt for his icon pack (Clean Icons - Crisp).
- Added Earthen Leg Armor enchant.
- I changed some items IDs because that's the only way for them to show. Here's the list:
-- Vereesa's Dexterity:        47545 -> 80000
-- Sylvanna's Cunning:         47546 -> 80001
-- Varian's Furor:             47547 -> 80002
-- Garrosh's Rage:             47548 -> 80003
-- Magni's Resolution:         47549 -> 80004
-- Cairne's Endurance:         47550 -> 80005
-- Aetha's Intensity:          47551 -> 80006
-- Jaina's Radiance:           47552 -> 80007
-- Bolvar's Resolution:        47553 -> 80008
-- Lady Liadrin's Conviction:  47554 -> 80009
-- Death's Verdict (H):        47131 -> 80010
-- Death's Choice (H):         47464 -> 80011
-- Solace of the Defeated:     47059 -> 80012
-- Solace of the Fallen:       47432 -> 80013
-- Reign of the Unliving:      47188 -> 80014
-- Reign of the Dead:          47477 -> 80015
-- Satrina's Impeding Scarab:  47088 -> 80016
-- Juggernaut's Vitality:      47451 -> 80017


Rawr Known Bugs:
- Hunter's module doesn't work at all unless you choose a ranged weapon first.
- When you select the talent "Veteran of the Third War" (Blood DK) the application forces close, that's why I added a Blood.xml sheet with the talent enabled, it works this way.
- If you try to select a relic or trinket in Elemental Shaman's module, Rawr crashes. That's why I added a Elemental.xml for you to edit. To change them, you have to force them by editing the .XML file directly.